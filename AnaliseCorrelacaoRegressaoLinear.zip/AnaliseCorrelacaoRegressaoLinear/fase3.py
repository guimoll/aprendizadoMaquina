import matUtils
import graficos
#ITEM A
#x,y = matUtils.load_data_fase3(False,0)
#print(matUtils.load_data_fase3(False,0))

#ITEM B
#x,y = matUtils.load_data_fase3(False,0)
#graficos.plot_dataset(x,y, "Grafico dispersao item b")


#ITEM C
x,y = matUtils.load_data_fase3(False,0)
bn_train = matUtils.demo_regressaop(x, y, 1)
bn_invertida_train = bn_train[::-1]
graficos.plot_regression_3d_fase3(x, y, "Grafico n1 item c",'red', bn_invertida_train)

#ITEM D
x,y = matUtils.load_data_fase3(False,0)
bn_train = matUtils.demo_regressaop(x, y, 2)
bn_invertida_train = bn_train[::-1]
graficos.plot_regression_3d_fase3(x, y,"Grafico n2 item d",'green', bn_invertida_train)

#ITEM E
x,y = matUtils.load_data_fase3(False,0)
bn_train = matUtils.demo_regressaop(x, y, 3)
bn_invertida_train = bn_train[::-1]
graficos.plot_regression_3d_fase3(x, y,"Grafico n3 item E",'black', bn_invertida_train)

#ITEM F
x,y = matUtils.load_data_fase3(False,0)
bn_train = matUtils.demo_regressaop(x, y, 8)
bn_invertida_train = bn_train[::-1]
graficos.plot_regression_3d_fase3(x, y,"Grafico n8 item F",'yellow', bn_invertida_train)

#ITEM G
x,y = matUtils.load_data_fase3(False,0)
print("EQM manual de varios graus:", matUtils.calcular_eqm_multiplos_graus(x,y,[1,2,3,8]))
print("------------------------------------------------")
print("EQM da base de dados separada para treino")
#Item H,I

x_treino, y_treino, x_teste, y_teste = matUtils.load_data_fase3(True,0.1)
bn_train = matUtils.demo_regressaop(x_treino, y_treino, 1)
bn_invertida_train = bn_train[::-1]
graficos.plot_regression_3d_fase3(x_treino, y_treino, "Grafico treinamento n1",'red', bn_invertida_train)

x_treino, y_treino, x_teste, y_teste = matUtils.load_data_fase3(True,0.1)
bn_train = matUtils.demo_regressaop(x_treino, y_treino, 2)
bn_invertida_train = bn_train[::-1]
graficos.plot_regression_3d_fase3(x_treino, y_treino,"Grafico treinamento n2",'green', bn_invertida_train)

x_treino, y_treino, x_teste, y_teste = matUtils.load_data_fase3(True,0.1)
bn_train = matUtils.demo_regressaop(x_treino, y_treino, 3)
bn_invertida_train = bn_train[::-1]
graficos.plot_regression_3d_fase3(x_treino, y_treino,"Grafico treinamento n3",'black', bn_invertida_train)

x_treino, y_treino, x_teste, y_teste = matUtils.load_data_fase3(True,0.1)
bn_train = matUtils.demo_regressaop(x_treino, y_treino, 8)
bn_invertida_train = bn_train[::-1]
graficos.plot_regression_3d_fase3(x_treino, y_treino,"Grafico treinamento n8",'yellow', bn_invertida_train)

#replicar dados de treino para teste
x_treino, y_treino, x_teste, y_teste = matUtils.load_data_fase3(True,0.1)
bn_train = matUtils.demo_regressaop(x_treino, y_treino, 1)
bn_invertida_teste = bn_train[::-1]
graficos.plot_regression_3d_fase3(x_teste, y_teste, "Grafico teste n1",'red', bn_invertida_teste)

x_treino, y_treino, x_teste, y_teste = matUtils.load_data_fase3(True,0.1)
bn_train = matUtils.demo_regressaop(x_treino, y_treino, 2)
bn_invertida_teste = bn_train[::-1]
graficos.plot_regression_3d_fase3(x_teste, y_teste,"Grafico teste n2",'green', bn_invertida_teste)

x_treino, y_treino, x_teste, y_teste = matUtils.load_data_fase3(True,0.1)
bn_train = matUtils.demo_regressaop(x_treino, y_treino, 3)
bn_invertida_teste = bn_train[::-1]
graficos.plot_regression_3d_fase3(x_treino, y_treino,"Grafico teste n3",'black', bn_invertida_teste)

x_treino, y_treino, x_teste, y_teste = matUtils.load_data_fase3(True,0.1)
bn_train = matUtils.demo_regressaop(x_treino, y_treino, 8)
bn_invertida_teste = bn_train[::-1]
graficos.plot_regression_3d_fase3(x_teste, y_teste,"Grafico teste n8",'yellow', bn_invertida_teste)



#Item J
x_train, y_train, x_test, y_test = matUtils.load_data_fase3(True, 0.1)

for n in range(1, 9):

    if (n == 4) or (n == 5) or (n == 6) or (n == 7):
        continue
    bn_train = matUtils.demo_regressaop(x_train, y_train, n)
    bn_invertida_train = bn_train[::-1]
    bn_test = matUtils.demo_regressaop(x_test, y_test, n)
    bn_invertida_test = bn_test[::-1]


    yHat_train = matUtils.getYhatManual(x_train, bn_invertida_train)
    yHat_test = matUtils.getYhatManual(x_test, bn_invertida_train)

    eqm_train = matUtils.EQM_manual(y_train, yHat_train)
    eqm_test = matUtils.EQM_manual(y_test, yHat_test)
    r2_train, r2_test = matUtils.calcular_r2(x_train, y_train, x_test, y_test, bn_invertida_train, bn_invertida_train)

    print("EQM (treino) para o N:",n, "igual a: ", eqm_train)
    print("EQM (teste) para o N: ",n, " igual a: ", eqm_test)
    print("R² (treino) para o N: ",n, " igual a: ", r2_train)
    print("R² (teste) para o N: ",n, " igual a: ", r2_test)
    print("-"*100)

#De acordo com os dados do r2 e do EQM, temos o maior r2 e o menor EQM para o grau 3,
# tanto para os dados de treino quanto para os dados de teste.
